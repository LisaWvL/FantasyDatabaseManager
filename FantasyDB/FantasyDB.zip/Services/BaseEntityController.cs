﻿// Part 1: BaseEntityController with junction support (split in two messages)
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FantasyDB.Models;
using FantasyDB.ViewModels;
using AutoMapper;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using static FantasyDB.Models.JunctionClasses;

namespace FantasyDB.Services
{
    [Route("api/[controller]")]
    public abstract class BaseEntityController<TModel, TViewModel> : Controller
        where TModel : class, new()
        where TViewModel : class, IViewModelWithId
    {
        protected readonly AppDbContext _context;
        protected readonly IMapper _mapper;
        protected readonly IDropdownService _dropdownService;

        protected BaseEntityController(AppDbContext context, IMapper mapper, IDropdownService dropdownService)
        {
            _context = context;
            _mapper = mapper;
            _dropdownService = dropdownService;
        }

        protected abstract IQueryable<TModel> GetQueryable();

        [HttpGet]
        public virtual async Task<IActionResult> Index()
        {
            var entities = await GetQueryable().AsNoTracking().ToListAsync();
            var viewModels = _mapper.Map<List<TViewModel>>(entities);
            return Ok(viewModels);
        }

        [HttpGet("{id}")]
        public virtual async Task<IActionResult> GetById(int id)
        {
            var entity = await _context.Set<TModel>().FindAsync(id);
            if (entity == null) return NotFound();

            var viewModel = _mapper.Map<TViewModel>(entity);
            return Ok(viewModel);
        }

        [HttpPost]
        public virtual async Task<IActionResult> Create([FromBody] TViewModel viewModel)
        {
            if (!ModelState.IsValid)
            {
                var errors = string.Join("\n", ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage));
                return BadRequest("Invalid model:\n" + errors);
            }

            var entity = _mapper.Map<TModel>(viewModel);
            _context.Add(entity);
            await _context.SaveChangesAsync();

            await SaveJunctionsAsync(entity, viewModel);

            var createdViewModel = _mapper.Map<TViewModel>(entity);
            return CreatedAtAction(nameof(GetById), new { id = createdViewModel.Id }, createdViewModel);
        }

        [HttpPut("{id}")]
        public virtual async Task<IActionResult> Update(int id, [FromBody] TViewModel viewModel)
        {
            if (viewModel == null || id != viewModel.Id)
                return BadRequest("Invalid request");

            var entity = await _context.Set<TModel>().FindAsync(id);
            if (entity == null) return NotFound();

            _mapper.Map(viewModel, entity);
            _context.Update(entity);
            await _context.SaveChangesAsync();

            await SaveJunctionsAsync(entity, viewModel);

            return Ok(new { message = "Entity updated" });
        }

        [HttpDelete("{id}")]
        public virtual async Task<IActionResult> Delete(int id)
        {
            var entity = await _context.Set<TModel>().FindAsync(id);
            if (entity == null) return NotFound();

            _context.Remove(entity);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Entity deleted" });
        }
        protected void SetCurrentEntityName()
        {
            var name = typeof(TModel).Name;
            ViewData["CurrentEntity"] = name;
        }

        protected async Task LoadDropdownsForViewModel<T>()
        {
            await _dropdownService.LoadDropdownsForViewModel<T>(ViewData);
        }

        [HttpGet("{id}/new-snapshot")]
        public virtual async Task<IActionResult> CreateNewSnapshot(int id)
        {
            var original = await _context.Set<TModel>().FindAsync(id);
            if (original == null) return NotFound();

            var viewModel = _mapper.Map<TViewModel>(original);
            viewModel.Id = 0;

            var snapshotProp = typeof(TViewModel).GetProperty("SnapshotId");
            snapshotProp?.SetValue(viewModel, null);

            await LoadDropdownsForViewModel<TViewModel>();
            ViewData["CurrentEntity"] = typeof(TModel).Name;

            return View("_EntityTableRow", new List<TViewModel> { viewModel });
        }

        [HttpGet("{id}/new-snapshot-page")]
        public virtual async Task<IActionResult> CreateNewSnapshotPage(int id)
        {
            var modelType = typeof(TModel);
            var navPropsToInclude = new[] { "Faction", "Location", "Language", "Snapshot", "Event", "Era" };

            var originalQuery = _context.Set<TModel>().AsQueryable();
            foreach (var navProp in navPropsToInclude)
            {
                var prop = modelType.GetProperty(navProp);
                if (prop != null && prop.PropertyType.IsClass && prop.PropertyType != typeof(string))
                    originalQuery = originalQuery.Include(navProp);
            }

            var original = await originalQuery.FirstOrDefaultAsync(e => EF.Property<int>(e, "Id") == id);
            if (original == null) return NotFound();

            var viewModel = _mapper.Map<TViewModel>(original);
            viewModel.Id = 0;

            var snapshotProp = typeof(TViewModel).GetProperty("SnapshotId");
            snapshotProp?.SetValue(viewModel, null);

            var nameProp = typeof(TViewModel).GetProperty("Name");
            var nameValue = nameProp?.GetValue(viewModel)?.ToString();

            var otherVersionsQuery = _context.Set<TModel>().AsQueryable().AsNoTracking();
            foreach (var navProp in navPropsToInclude)
            {
                var prop = modelType.GetProperty(navProp);
                if (prop != null && prop.PropertyType.IsClass && prop.PropertyType != typeof(string))
                    otherVersionsQuery = otherVersionsQuery.Include(navProp);
            }

            var otherVersions = string.IsNullOrEmpty(nameValue)
                ? new List<TModel>()
                : await otherVersionsQuery.Where(e => EF.Property<string>(e, "Name") == nameValue).ToListAsync();

            var versionVMs = _mapper.Map<List<TViewModel>>(otherVersions);

            await LoadDropdownsForViewModel<TViewModel>();
            ViewData["CurrentEntity"] = typeof(TModel).Name;

            var pageModel = new SnapshotEditPageViewModel<TViewModel>
            {
                NewSnapshot = viewModel,
                ExistingVersions = versionVMs
            };

            return View("~/Views/Shared/CreateNewSnapshot.cshtml", pageModel);
        }

        protected virtual async Task SaveJunctionsAsync(TModel entity, TViewModel viewModel)
        {
            var entityName = typeof(TModel).Name;

            if (entityName == "Location" && viewModel is LocationViewModel vm)
            {
                var locationId = (int)typeof(TModel).GetProperty("Id")?.GetValue(entity)!;

                _context.LocationEvent.RemoveRange(_context.LocationEvent.Where(e => e.LocationId == locationId));
                _context.LocationLocation.RemoveRange(_context.LocationLocation.Where(l => l.LocationId == locationId));

                foreach (var id in vm.EventIds ?? new List<int>())
                    _context.LocationEvent.Add(new LocationEvent { LocationId = locationId, EventId = id });

                foreach (var id in vm.ChildLocationIds ?? new List<int>())
                    _context.LocationLocation.Add(new LocationLocation { LocationId = locationId, ChildLocationId = id });

                await _context.SaveChangesAsync();
            }

            if (typeof(TModel) == typeof(Character) && viewModel.GetType().GetProperty("SnapshotId")?.GetValue(viewModel) is int snapshotId)
            {
                var characterId = (int)typeof(TModel).GetProperty("Id")?.GetValue(entity)!;
                if (!_context.SnapshotCharacter.Any(sc => sc.CharacterId == characterId && sc.SnapshotId == snapshotId))
                {
                    _context.SnapshotCharacter.Add(new SnapshotCharacter { CharacterId = characterId, SnapshotId = snapshotId });
                    await _context.SaveChangesAsync();
                }
            }

            if (entityName == "Language" && viewModel is LanguageViewModel lvm)
            {
                var languageId = (int)typeof(TModel).GetProperty("Id")?.GetValue(entity)!;

                // 1. Remove the LanguageId from locations no longer in the list
                var allLocationIds = _context.Location
                    .Where(loc => loc.LanguageId == languageId)
                    .Select(loc => loc.Id)
                    .ToList();

                var removedLocationIds = allLocationIds.Except(lvm.LocationIds ?? new List<int>()).ToList();
                foreach (var id in removedLocationIds)
                {
                    var loc = await _context.Location.FindAsync(id);
                    if (loc != null)
                    {
                        loc.LanguageId = null;
                    }
                }

                // 2. Set the LanguageId on each selected location
                foreach (var locId in lvm.LocationIds ?? new List<int>())
                {
                    var location = await _context.Location.FindAsync(locId);
                    if (location != null)
                    {
                        location.LanguageId = languageId;
                    }
                }

                await _context.SaveChangesAsync();
            }



            // Repeat similar if blocks for: SnapshotArtifact, SnapshotEra, SnapshotEvent, etc. as needed
        }
    }
}
