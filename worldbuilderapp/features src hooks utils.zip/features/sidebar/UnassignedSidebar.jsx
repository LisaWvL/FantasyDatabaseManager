// src/components/UnassignedSidebar.jsx
import './UnassignedSidebar.css';

export default function UnassignedSidebar({
    isSidebarOpen,
    setIsSidebarOpen,
    isOverSidebar,
    onSidebarDragOver,
    onSidebarDragLeave,
    onDropToUnassigned,
    onContextMenu,
    renderItem,
    entityType,
    items,
    isUnassigned,
}) {
    return (
        <div className={`unassigned-sidebar-wrapper ${isSidebarOpen ? 'open' : 'collapsed'}`}>
            <div
                className={`unassigned-sidebar ${isSidebarOpen ? 'open' : 'collapsed'} ${isOverSidebar ? 'highlight-drop' : ''}`}
                onDragOver={onSidebarDragOver}
                onDragLeave={onSidebarDragLeave}
                onDrop={(e) => {
                    const itemId = parseInt(e.dataTransfer.getData('entityId'));
                    if (!isNaN(itemId)) {
                        onDropToUnassigned?.(itemId);
                    }
                }}
            >
                <button
                    className="unassigned-sidebar-toggle"
                    onClick={() => setIsSidebarOpen?.(!isSidebarOpen)}
                >
                    MORE
                </button>

                <h3>Unassigned {capitalize(entityType)}s</h3>
                {items.filter(isUnassigned).map(item => (
                    <div
                        key={item.id}
                        onContextMenu={(e) => {
                            e.preventDefault();
                            onContextMenu?.(e, item, entityType);
                        }}
                    >

                        {renderItem(item)}
                    </div>
                ))}
            </div>
        </div>
    );
}

function capitalize(str) {
    return str.charAt(0).toUpperCase?.() + str.slice(1);
}


//// src/components/UnassignedSidebar.jsx
//import './UnassignedSidebar.css';
//import React from 'react';
////import { useDragAndDrop } from '../../hooks/useDragAndDrop';
////import { useEntityContextMenu } from '../../hooks/useEntityContextMenu';
//import '../../src/layout/MainLayout.css';

//export default function UnassignedSidebar({
//    isSidebarOpen,
//    setIsSidebarOpen,
//    isOverSidebar,
//    onSidebarDragOver,
//    onSidebarDragLeave,
//    onDropToUnassigned,
//    onContextMenu,
//    renderItem,
//    entityType,
//    items,
//    isUnassigned,
//}) {
//    return (
//        <div className={`unassigned-sidebar-wrapper ${isSidebarOpen ? 'open' : 'collapsed'}`}>
//            <div
//                className={`unassigned-sidebar ${isSidebarOpen ? 'open' : 'collapsed'} ${isOverSidebar ? 'highlight-drop' : ''}`}
//                onDragOver={onSidebarDragOver}
//                onDragLeave={onSidebarDragLeave}
//                onDrop={(e) => {
//                    const itemId = parseInt(e.dataTransfer.getData('entityId'));
//                    const entityType = e.dataTransfer.getData('entityType');
//                    if (!isNaN(itemId)) {
//                        onDropToUnassigned?.(itemId, entityType);
//                    }
//                }}
//            >
//                <button
//                    className="unassigned-sidebar-toggle"
//                    onClick={() => setIsSidebarOpen?.(!isSidebarOpen)}
//                >
//                    MORE
//                </button>

//                <h3>Unassigned {capitalize(entityType)}s</h3>
//                {items.filter(isUnassigned).map(item => (
//                    <div
//                        key={`${item.entityType?.toLowerCase?.()}-${item.id}`}
//                        onContextMenu={(e) => {
//                            e.preventDefault();
//                            onContextMenu?.(e, item, entityType);
//                        }}
//                    >
//                        {renderItem(item)}
//                    </div>
//                ))}

//            </div>
//        </div>
//    );
//}

//function capitalize(str) {
//    return str.charAt(0).toUpperCase?.() + str.slice(1);
//} 