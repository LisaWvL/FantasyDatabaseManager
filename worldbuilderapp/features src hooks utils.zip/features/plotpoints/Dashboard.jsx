﻿import React, { useEffect, useState } from 'react';
import CalendarDayCell from './CalendarDayCell';
import PlotPointCard from './PlotPointCard';
import PlotPointModal from './PlotPointModal';
import { useEntityContextMenu } from '../../hooks/useEntityContextMenu';
import { fetchCalendarGrid } from './CalendarApi';
import { fetchPlotPoints, updatePlotPoint } from './PlotPointApi';
import { EntityDeleter } from '../entities/entityManager';
import MainLayout from '../../src/layout/MainLayout'; // ✅ Wraps full layout
import {EntityUpdater } from '../entities/entityManager'
import './Dashboard.css';

export default function Dashboard() {
    const [calendar, setCalendar] = useState([]);
    const [plotPoints, setPlotPoints] = useState([]);
    const [collapsedMonths, setCollapsedMonths] = useState({});
    const [showModal, setShowModal] = useState(false);
    const [newPlotPointId, setNewPlotPointId] = useState(null);
    //const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    //const [isOverSidebar, setIsOverSidebar] = useState(false);
    const [editingPlotPointId, setEditingPlotPointId] = useState(null);

    useEffect(() => {
        async function loadInitialData() {
            const [calendarData, plotPointData] = await Promise.all([
                fetchCalendarGrid(),
                fetchPlotPoints(),
            ]);
            setCalendar(calendarData);
            setPlotPoints(plotPointData);
        }
        loadInitialData();
    }, []);

    const calendarById = Object.fromEntries(calendar.map(day => [day.id, day]));

    const groupedByMonth = calendar.reduce((acc, day) => {
        if (!acc[day.month]) acc[day.month] = [];
        acc[day.month].push(day);
        return acc;
    }, {});

    const plotpointsByDay = plotPoints.reduce((acc, pp) => {
        if (!pp.startDateId) return acc;

        const isReversed = pp.endDateId && pp.endDateId < pp.startDateId;
        const start = isReversed ? pp.endDateId : pp.startDateId;
        const end = isReversed ? pp.startDateId : (pp.endDateId || pp.startDateId);
        const colorIndex = pp.id % 10;

        for (let dayId = start; dayId <= end; dayId++) {
            if (!calendarById[dayId]) continue;
            if (!acc[dayId]) acc[dayId] = [];
            acc[dayId].push({
                ...pp,
                isGhost: dayId !== (isReversed ? pp.endDateId : pp.startDateId),
                colorIndex,
                isReversed,
            });
        }

        return acc;
    }, {});

    const handleResize = async (plotPointId, direction, newDayId) => {
        const pp = plotPoints.find(p => p.id === plotPointId);
        if (!pp) return;

        const updated = {
            ...pp,
            startDateId: direction === 'start' ? newDayId : pp.startDateId,
            endDateId: direction === 'end' ? newDayId : (pp.endDateId ?? pp.startDateId),
        };

        const saved = await updatePlotPoint(plotPointId, updated);
        setPlotPoints(prev => prev.map(p => (p.id === plotPointId ? saved : p)));
    };

    const handleDropPlotPoint = async (plotPointId, dayId) => {
        const pp = plotPoints.find(p => p.id === plotPointId);
        if (!pp || pp.startDateId === dayId) return;

        const originalStart = pp.startDateId;
        const originalEnd = pp.endDateId ?? pp.startDateId;
        const isReversed = originalEnd < originalStart;
        const duration = Math.abs(originalEnd - originalStart);

        const newStart = isReversed ? dayId + duration : dayId;
        const newEnd = isReversed ? dayId : dayId + duration;

        const updated = { ...pp, startDateId: newStart, endDateId: newEnd };
        const saved = await updatePlotPoint(plotPointId, updated);
        setPlotPoints(prev => prev.map(p => (p.id === plotPointId ? saved : p)));
        setNewPlotPointId(null);
    };

    //function getFieldToNull(entityType, sourceContext) {
    //    if (entityType === 'PlotPoint' && sourceContext === 'CalendarDayCell') {
    //        return ['startDateId', 'endDateId'];
    //    }
    //    return null;
    //}


    //const handleDropToSidebar = async (plotPointId, entityType, sourceContext = 'CalendarDayCell') => {
    //    const fieldToNull = getFieldToNull(entityType, sourceContext);
    //    if (!fieldToNull) return;

    //    if (Array.isArray(fieldToNull)) {
    //        await Promise.all(fieldToNull.map((field) =>
    //            EntityUpdater.setNull(entityType, plotPointId, field)
    //        ));
    //    } else {
    //        await EntityUpdater.setNull(entityType, plotPointId, fieldToNull);
    //    }

    //    setPlotPoints(prev =>
    //        prev.map(p =>
    //            p.id === plotPointId
    //                ? {
    //                    ...p,
    //                    ...(Array.isArray(fieldToNull)
    //                        ? Object.fromEntries(fieldToNull.map(f => [f, null]))
    //                        : { [fieldToNull]: null }),
    //                }
    //                : p
    //        )
    //    );
    //};



    const handleNewPlotPoint = (saved) => {
        setPlotPoints(prev => {
            const existingIndex = prev.findIndex(p => p.id === saved.id);
            if (existingIndex !== -1) {
                const copy = [...prev];
                copy[existingIndex] = saved;
                return copy;
            }
            return [...prev, saved];
        });
        setNewPlotPointId(saved.id);
        setShowModal(false);
    };

    const handleDeleteEntity = async (entity) => {
        try {
            await EntityDeleter.delete('PlotPoint', entity.id);
            setPlotPoints(prev => prev.filter(p => p.id !== entity.id));
        } catch (err) {
            console.error(`❌ Failed to delete PlotPoint`, err);
        }
    };

    const { showContextMenu, contextMenuPortal } = useEntityContextMenu({
        onCreate: () => setShowModal(true),
        onEdit: (entity) => {
            setEditingPlotPointId(entity.id);
            setShowModal(true);
        },
        onDelete: handleDeleteEntity,
    });

    return (
        <>
            <div className="sticky-header">
                <button className="add-button" onClick={() => setShowModal(true)}>
                    ＋ Add PlotPoint
                </button>
            </div>

            {Object.entries(groupedByMonth).map(([month, days]) => (
                <div key={month} className="month-block">
                    <div className="month-header sticky">
                        <button
                            className="collapse-btn"
                            onClick={() =>
                                setCollapsedMonths(prev => ({ ...prev, [month]: !prev[month] }))
                            }
                        >
                            {collapsedMonths[month] ? '▶' : '▼'} {month}
                        </button>
                    </div>
                    {!collapsedMonths[month] && (
                        <div className="calendar-grid">
                            {days.map((day) => (
                                <CalendarDayCell
                                    key={day.id}
                                    day={day}
                                    weekday={calendarById[day.id]}
                                    onDropPlotPoint={handleDropPlotPoint}
                                >
                                    {(plotpointsByDay[day.id] || []).map(pp => (
                                        <PlotPointCard
                                            key={`${pp.id}-${day.id}`}
                                            plotPoint={pp}
                                            isGhost={pp.isGhost}
                                            colorIndex={pp.colorIndex}
                                            onResizeEnd={handleResize}
                                            onContextMenu={(e) => showContextMenu(e, pp, 'plotpoint')}
                                        />
                                    ))}
                                    {newPlotPointId &&
                                        newPlotPointId ===
                                        (plotpointsByDay[day.id] || []).find(p => p.id === newPlotPointId)?.id && (
                                            <div className="new-plotpoint-hint">📌 Drop here</div>
                                        )}
                                </CalendarDayCell>
                            ))}
                        </div>
                    )}
                </div>
            ))}

            {contextMenuPortal}
            {showModal && (
                <PlotPointModal
                    onClose={() => {
                        setShowModal(false);
                        setEditingPlotPointId(null);
                    }}
                    onSave={handleNewPlotPoint}
                    plotPointId={editingPlotPointId}
                />
            )}
        </>
    );
}