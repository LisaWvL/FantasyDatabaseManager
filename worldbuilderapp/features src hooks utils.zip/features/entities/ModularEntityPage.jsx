﻿import React, { useEffect, useState } from 'react';
import EntityCard from './EntityCard';
import MainLayout from '../../src/layout/MainLayout';
import { safeLower } from '../../utils/UpperLowerCase';
import '../../src/layout/MainLayout.css'
import {
    EntityFetcher,
    EntityUpdater,
    EntityDeleter,
    EntityCreator
} from './entityManager';
import { entitySchemas } from './entitySchemas';
import useDragScroll from '../..//hooks/useDragScroll';
import './ModularEntityPage.css';

export default function ModularEntityPage({ cardEntity, sectionEntity, updateFK }) {
    const cardSchema = entitySchemas[cardEntity];
    const sectionSchema = entitySchemas[sectionEntity];

    const [cards, setCards] = useState([]);
    const [sections, setSections] = useState([]);
    const [dragOverSectionId, setDragOverSectionId] = useState(null);
    const [isDragging, setIsDragging] = useState(false);
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [isOverSidebar, setIsOverSidebar] = useState(false);

    useDragScroll(isDragging);

    useEffect(() => {
        const loadData = async () => {
            try {
                const [loadedSections, loadedCards] = await Promise.all([
                    EntityFetcher.fetchAll(sectionEntity),
                    EntityFetcher.fetchAll(cardEntity)
                ]);
                setSections(loadedSections);
                setCards(loadedCards);
            } catch (err) {
                console.error(`❌ Failed to load modular entity page data`, err);
            }
        };
        loadData();
    }, [cardEntity, sectionEntity]);

    const handleDragStart = () => setIsDragging(true);
    const handleDragEnd = () => setIsDragging(false);

    const handleUpdateCard = async (updatedCard) => {
        try {
            const saved = await EntityUpdater.update(cardEntity, updatedCard.id, updatedCard);
            setCards((prev) => prev.map((c) => (c.id === saved.id ? saved : c)));
        } catch (err) {
            console.error(`❌ Failed to update ${cardEntity}`, err);
        }
    };

    const handleDeleteEntity = async (card) => {
        try {
            await EntityDeleter.delete(cardEntity, card.id);
            setCards((prev) => prev.filter((c) => c.id !== card.id));
        } catch (err) {
            console.error(`❌ Failed to delete ${cardEntity}`, err);
        }
    };

    const handleCreateNewEntity = async () => {
        try {
            const newPayload = {
                name: `New ${cardEntity}`,
                [updateFK]: null
            };
            const created = await EntityCreator.create(cardEntity, newPayload);
            setCards((prev) => [created, ...prev]);
        } catch (err) {
            console.error(`❌ Failed to create new ${cardEntity}`, err);
        }
    };

    const handleDropToUnassigned = async (cardId) => {
        const card = cards.find((c) => c.id === cardId);
        if (!card) return;

        const updatedCard = { ...card, [updateFK]: null };
        await handleUpdateCard(updatedCard);
    };

    const PageContent = (
        <div className="entity-page">
            <div className="entity-page-header">
                <h2>{cardSchema.label} Assignment</h2>
                <button onClick={handleCreateNewEntity}>➕ Add {cardSchema.label}</button>
            </div>

            {sections.map((section) => {
                const sectionCards = cards.filter((c) => c[updateFK] === section.id);
                return (
                    <div
                        key={section.id}
                        className={`chapter-section ${dragOverSectionId === section.id ? 'drag-over' : ''}`}
                        onDragOver={(e) => e.preventDefault()}
                        onDragEnter={() => setDragOverSectionId(section.id)}
                        onDragLeave={(e) => {
                            if (e.relatedTarget && e.currentTarget && !e.currentTarget.contains(e.relatedTarget instanceof Node ? e.relatedTarget : null)) {
                                setDragOverSectionId(null);
                            }
                        }}
                        onDrop={(e) => {
                            e.preventDefault();
                            const draggedId = parseInt(e.dataTransfer.getData(`${safeLower(cardEntity, 'ModularEntityPage: drag read')}Id`));
                            const draggedCard = cards.find((c) => c.id === draggedId);
                            if (!draggedCard) return;

                            const updatedCard = { ...draggedCard, [updateFK]: section.id };
                            handleUpdateCard(updatedCard);
                            setDragOverSectionId(null);
                        }}
                    >
                        <div className="chapter-header">
                            <h3>{section.title || section.name || `${sectionSchema.label} #${section.id}`}</h3>
                        </div>
                        <div className="entity-card-row">
                            {sectionCards.map((card) => (
                                <EntityCard
                                    key={card.id}
                                    entity={card}
                                    entityType={cardEntity}
                                    schema={cardSchema}
                                    onUpdate={handleUpdateCard}
                                    onDelete={() => handleDeleteEntity(card)}
                                    onCreateNewEntity={handleCreateNewEntity}
                                    draggable
                                    onDragStart={(e) => {
                                        e.dataTransfer.setData(`${safeLower(cardEntity, 'ModularEntityPage: drag set (start)')}Id`, card.id);
                                        handleDragStart();
                                    }}
                                    onDragEnd={handleDragEnd}
                                />
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
    );

    return (
        <MainLayout
            headerContent={<h2>{cardSchema.label} Assignment</h2>}
            content={PageContent}
            unassignedSidebar={{
                entityType: cardEntity,
                items: cards,
                isUnassigned: (c) => !c[updateFK],
                onDropToUnassigned: handleDropToUnassigned,
                onContextMenu: (e, item) => {
                    e.preventDefault();
                    console.log('Right-clicked', item);
                },
                renderItem: (item) => (
                    <EntityCard
                        key={item.id}
                        entity={item}
                        entityType={cardEntity}
                        schema={cardSchema}
                        onUpdate={handleUpdateCard}
                        onDelete={() => handleDeleteEntity(item)}
                        onCreateNewEntity={handleCreateNewEntity}
                        draggable
                        onDragStart={(e) => {
                            e.dataTransfer.setData(`${safeLower(cardEntity, 'ModularEntityPage: drag set (item)')}Id`, item.id);
                            handleDragStart();
                        }}
                        onDragEnd={handleDragEnd}
                    />
                ),
                isSidebarOpen,
                setIsSidebarOpen,
                isOverSidebar,
                onSidebarDragOver: () => setIsOverSidebar(true),
                onSidebarDragLeave: () => setIsOverSidebar(false)
            }}
        />
    );
}