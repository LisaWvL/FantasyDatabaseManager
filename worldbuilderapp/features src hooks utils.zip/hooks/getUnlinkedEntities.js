//import { useEffect } from 'react';
//import { useState } from 'react';
//import { useRef } from 'react';



     //const [unlinkedEntities, setUnlinkedEntities] = useState([]);
     //useEffect(() => {
     //    const filteredEntities = entities.filter(e => e.chapterId !== currentChapterId);
     //    setUnlinkedEntities(filteredEntities);
     //}, [entities, currentChapterId]);



//return (entities.filter(e => e.chapterId !== currentChapterId)
//    < td >
//    <select name="character1Id" value={formData.character1Id} onChange={handleChange}>
//        <option value="">-- Select --</option>
//        {characters.map((c) => (
//            <option key={c.id} value={c.id}>
//                {c.name}
//            </option>
//        ))}
//    </select>
//)};