const API_BASE = 'https://localhost:56507/api';

export async function fetchEntities(entityType, chapterId = null) {
  const url = chapterId
    ? `${API_BASE}/${entityType}?chapterId=${chapterId}`
    : `${API_BASE}/${entityType}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Failed to load ${entityType}`);
  return await response.json();
}

export async function fetchEntityById(entityType, id) {
  const response = await fetch(`${API_BASE}/${entityType}/${id}`);
  if (!response.ok) throw new Error(`Failed to load ${entityType} with id ${id}`);
  return await response.json();
}


export async function setNull(entityType, id, field) {
    const res = await fetch(`${API_BASE}/${entityType}/${id}/setnull?fieldName=${field}`, {
        method: 'PATCH',
    });
    if (!res.ok) throw new Error(`Failed to set '${field}' to null on ${entityType} with ID ${id}`);
    return await res.json();
}


export async function createEntity(entityType, payload) {
  const response = await fetch(`${API_BASE}/${entityType}/create`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error(`Failed to create ${entityType}`);
  return await response.json();
}

export async function updateEntity(entityType, id, payload) {
  const response = await fetch(`${API_BASE}/${entityType}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!response.ok) throw new Error(`Failed to update ${entityType} with id ${id}`);
  return await response.json();
}

export async function deleteEntity(entityType, id) {
  const response = await fetch(`${API_BASE}/${entityType}/${id}`, {
    method: 'DELETE',
  });
  if (!response.ok) throw new Error(`Failed to delete ${entityType} with id ${id}`);
  return true;
}

export async function fetchFlatEntity(entityType) {
    const response = await fetch(`${API_BASE}/${entityType}/flat`, {
        method: 'GET',
    });
    if (!response.ok) throw new Error(`Failed to fetch flat entity of type  ${entityType}`);
    return true;
}
