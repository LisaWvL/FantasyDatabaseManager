﻿import { useState } from 'react';
import { Outlet } from 'react-router-dom';

import NavSidebar from '../../features/sidebar/NavSidebar.jsx';
import UnassignedSidebar from '../../features/sidebar/UnassignedSidebar.jsx';

import '../../features/sidebar/UnassignedSidebar.css';
import '../../features/sidebar/NavSidebar.css';
import './MainLayout.css';
import {EntityUpdater, EntityFetcher, EntityCreator } from '../../features/entities/entityManager.js'

export default function MainLayout() {
    const [sidebarOpen, setSidebarOpen] = useState(true);
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const [isOverSidebar, setIsOverSidebar] = useState(false);
    const [unassignedItems, _setUnassignedItems] = useState([]);
    const entityType = 'entity'; // Replace with your actual entity type logic

    const toggleSidebar = () => setSidebarOpen((prev) => !prev);

    const onSidebarDragOver = (e) => {
        e.preventDefault();
        setIsOverSidebar(true);
    };

    const onSidebarDragLeave = () => {
        setIsOverSidebar(false);
    };

    function getFieldToNull(entityType, sourceContext) {
        if (entityType === 'Chapter' && sourceContext === 'WritingAssistantPage') return 'povCharacterId';
        if (entityType === 'PlotPoint' && sourceContext === 'CalendarDayCell') return ['startDateId', 'endDateId'];
        if (entityType === 'Character' && sourceContext === 'FactionsPage') return 'factionId';
        return null;
    }


    async function onDropToUnassigned(entityId, entityType, sourceContext) {
        console.log('🟡 onDropToUnassigned called with:', { entityId, entityType, sourceContext });

        const fieldToNull = getFieldToNull(entityType, sourceContext);
        if (!fieldToNull) {
            console.warn('No matching field to clear', { entityType, sourceContext });
            return;
        } else {
            await EntityUpdater.setNull(entityType, entityId, fieldToNull);
        }
    }



    const onContextMenu = (e, item, type) => {
        console.log('Context menu on:', item, type);
        // Handle your custom context menu logic
    };

    const renderItem = (item) => (
        <div className="unassigned-entity-card">
            {item.name ?? 'Unnamed'} (ID: {item.id})
        </div>
    );

    const isUnassigned = (item) => !item.chapterId && !item.eraId; // Customize condition

    return (
        <div className="app-shell">
            {/* Top Header */}
            <div className="sticky-header">
                <h1>Worldbuilder</h1>
            </div>

            {/* Layout */}
            <div className="layout-row">
                <NavSidebar show={sidebarOpen} toggle={toggleSidebar} />

                <div className={`main-container ${isSidebarOpen ? 'with-unassigned-sidebar' : ''}`}>
                    <Outlet />
                </div>

                <UnassignedSidebar
                    isSidebarOpen={isSidebarOpen}
                    setIsSidebarOpen={setIsSidebarOpen}
                    isOverSidebar={isOverSidebar}
                    onSidebarDragOver={onSidebarDragOver}
                    onSidebarDragLeave={onSidebarDragLeave}
                    onDropToUnassigned={onDropToUnassigned}
                    onContextMenu={onContextMenu}
                    renderItem={renderItem}
                    entityType={entityType}
                    items={unassignedItems}
                    isUnassigned={isUnassigned}
                />
            </div>
        </div>
    );
}