//TODO
//this component will add the functionality, to add freeform tags to entities, they have a color, a text and a category
//this component will be named TagManager
//this component will be a functional component
//this component will be created in the components folder
//this component will be exported as the default export
//this component will import React
//this component will import the useState hook from React
//this component will have a state variable called tags, setTags
//this component will have a state variable called tag, setTag
//this component will have a state variable called color, setColor
//this component will have a state variable called category, setCategory
//this component will have a state variable called text, setText
//this component will have a state variable called selectedTag, setSelectedTag
//this component will have a state variable called selectedColor, setSelectedColor
//this component will have a state variable called selectedCategory, setSelectedCategory
//this component will have a state variable called selectedText, setSelectedText
//this component will have a state variable called isEditing, setIsEditing
//this component will have a state variable called isAdding, setIsAdding
//this component will have a state variable called isDeleting, setIsDeleting
//this component will have a state variable called isConfirming, setIsConfirming
//this component will have a state variable called isCancelling, setIsCancelling
//this component will have a state variable called isSaving, setIsSaving
