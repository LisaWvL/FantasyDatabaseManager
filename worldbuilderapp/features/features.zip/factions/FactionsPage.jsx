﻿// FactionsPage.jsx
import '../../features/entities/EntityPage.css';
import EntityPage from '../../features/entities/EntityPage';

export default function FactionsPage() {
  return <EntityPage entityType="Faction" />;
}
