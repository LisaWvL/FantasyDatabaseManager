﻿// CharacterPage.jsx

import '../entities/EntityPage.css';
import EntityPage from '../entities/EntityPage';

export default function CharactersPage() {
  return <EntityPage entityType="Character" />;
}
